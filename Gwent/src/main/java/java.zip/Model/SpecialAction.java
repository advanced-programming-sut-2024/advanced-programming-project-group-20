package Model;

public class SpecialAction {
    public static void bitingFrost(){

    }

    public static void impenetrableFog(){

    }

    public static void torrentialRain(){

    }

    public static void decoy() {

    }

    public static void Villentretenmerth(){

    }

    public static void toad(){

    }

    public static void schirru(){

    }

    public static void mardroeme() {

    }

    public static void berserker() {

    }


    public static void cerys(){

    }

    public static void kombi(){

    }

    public static void shieldmaide(){

    }

    public static void clanDimunPirate(){

    }
    public static void youngBerserker() {

    }
}
