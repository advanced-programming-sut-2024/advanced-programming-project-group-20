package Controller;

public class MainController {


    public void interMenu(String menuName) {

    }


    public static void exitMenu() {

    }

    public static String showCurrent() {
        return null;
    }

}
